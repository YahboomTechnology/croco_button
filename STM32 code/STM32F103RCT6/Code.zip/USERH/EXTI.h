#ifndef __EXTI_H__
#define __EXTI_H__

#include "stm32f10x.h"

void EXTI5_Init(void);

#endif
