#include "stm32f10x.h"
#include "LED.h"
#include "EXTI.h"

int main(void)
{
    LED_Init();//LED初始化(PB4)
    EXTI5_Init();//外部中断5初始化(PB5 EXTI5)
    
    while(1)
    {
        
    }
}
